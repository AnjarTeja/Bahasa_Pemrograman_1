-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2024 at 01:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_bp1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`, `level`) VALUES
('admin', 'admin123', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id` int(10) NOT NULL,
  `nama` varchar(225) NOT NULL,
  `jenis` varchar(255) NOT NULL,
  `spesifikasi` varchar(255) NOT NULL,
  `harga` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id`, `nama`, `jenis`, `spesifikasi`, `harga`) VALUES
(1, 'Axioo Pongo 725', 'Laptop', 'i7 12650H RTX 2050', 'Rp.10.000.000'),
(2, 'LOQ', 'Laptop', 'i5 12650HX RTX 3050', 'Rp.13.000.000'),
(3, 'Infinix Note 30', 'SmartPhone', 'Helio G99 8/256', 'Rp.2.500.000'),
(4, 'Xiaomi Note 10 Pro', 'SmartPhone', 'Snapdragon 732G 8/128', 'Rp.2.000.000'),
(5, 'Iphone 15 Pro', 'Iphone', 'A17 Pro 8/256', 'Rp.20.000.000');

-- --------------------------------------------------------

--
-- Table structure for table `data_barang`
--

CREATE TABLE `data_barang` (
  `id` int(10) NOT NULL,
  `kode_barang` varchar(225) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `jumlah` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_barang`
--

INSERT INTO `data_barang` (`id`, `kode_barang`, `nama_barang`, `nama_kategori`, `jumlah`) VALUES
(1, '01', 'Axioo Pongo 725', 'Laptop', 5),
(2, '02', 'ThinkPad L450', 'Laptop', 5),
(3, '03', 'Infinix Note 30', 'SmartPhone', 7),
(4, '04', 'Xiaomi Note 10 Pro', 'SmartPhone', 4),
(5, '05', 'Iphone 15 Pro Max', 'Iphone', 6),
(6, '06', 'MacBook Air M1', 'MacBook', 4);

-- --------------------------------------------------------

--
-- Table structure for table `data_kategori`
--

CREATE TABLE `data_kategori` (
  `id` int(10) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_kategori`
--

INSERT INTO `data_kategori` (`id`, `kode`, `nama`) VALUES
(1, '01', 'SmartPhone'),
(2, '02', 'Laptop'),
(3, '03', 'Iphone'),
(4, '04', 'MacBook');

-- --------------------------------------------------------

--
-- Table structure for table `data_pembeli`
--

CREATE TABLE `data_pembeli` (
  `nama` varchar(225) NOT NULL,
  `umur` varchar(225) NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `nohp` int(10) NOT NULL,
  `alamat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_pembeli`
--

INSERT INTO `data_pembeli` (`nama`, `umur`, `jk`, `nohp`, `alamat`) VALUES
('Anjar', '20', 'L', 12345, 'Subang'),
('Ahmad(Emod)', '20', 'L', 56789, 'Kuningan'),
('Dika', '45', 'L', 31412, 'Jawa'),
('Putri', '21', 'P', 56789, 'Kuningan'),
('Bayu', '55', 'L', 54321, 'Bekasi');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(225) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(225) NOT NULL,
  `level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `level`) VALUES
('user', 'user123', 'User');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_barang`
--
ALTER TABLE `data_barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_kategori`
--
ALTER TABLE `data_kategori`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `data_barang`
--
ALTER TABLE `data_barang`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `data_kategori`
--
ALTER TABLE `data_kategori`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
